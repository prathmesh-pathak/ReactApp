import React from 'react';
import Movie from './Movie';

const SearchMovie = (props) => {
    return (
        <div className="container">
            <div className="row">
                <div className="col s12">
                    {
                        props.movies.map((movie, index) => {
                            return (
                                <Movie key={index} title={movie.display_title} viewMovieInfo={props.viewMovieInfo} />
                            );
                        })
                    }
                </div>
            </div>
        </div>    
    );
}

export default SearchMovie;