import React from 'react';
import 'weather-icons/css/weather-icons.css'
import 'bootstrap/dist/css/bootstrap.min.css';

const SearchUniversity = (props) => {
    return(
        <div className="container center">
            <div className="cards pt-4">
                <h1>{props.city}</h1>
                <h5 className="py-4">
                    <i className={`wi ${props.weatherIcon} display-1`}></i>
                </h5>
                { props.fahrenheit ? (<h1 className="py-2">{props.fahrenheit}&deg;</h1>) : null }               
                {MinMaxTemperature(props.min_temp, props.max_temp)}

                <h4 className="py-3">{props.description}</h4>
            </div>
        </div>
    );
}

const MinMaxTemperature = (min, max) => {
    if(min && max){
        return(
            <h3>
                <span className="px-4">{min}&deg;</span>
                <span className="px-4">{max}&deg;</span>
            </h3>
        );
    }
}

export default SearchUniversity;