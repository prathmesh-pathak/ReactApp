import React from 'react';
import SearchUniversity from './SearchUniversity';
import SearchCity from './SearchCity';

const WEATHER_API_KEY = process.env.REACT_APP_WEATHER_API_KEY;

class GetWeatherComponent extends React.Component {
    constructor(){
        super();
        this.state = {
            city: undefined,
            country: undefined,
            icon: undefined,
            main: undefined,
            fahrenheit: undefined,
            max_temp: undefined,
            min_temp: undefined,
            description: "",
            error: false,
            displayFooter: true
        };
        this.weatherIcon = {
            ThunderStorm: "wi-thunderstorm",
            Drizzle: "wi-sleet",
            Rain: "wi-storm-showers",
            Snow: "wi-snow",
            Atmosphere: "wi-fog",
            Clear: "wi-day-sunny",
            Clouds: "wi-day-fog"
        }
    }

    getWeatherIcon = (icons, rangeId) => {
        switch(true){
            case rangeId >= 200 && rangeId <= 232:
                this.setState({icon: this.weatherIcon.ThunderStorm});
                break;
            case rangeId >= 300 && rangeId <= 321:
                this.setState({icon: this.weatherIcon.Drizzle});
                break;
            case rangeId >= 500 && rangeId <= 531:
                this.setState({icon: this.weatherIcon.Rain});
                break;
            case rangeId >= 600 && rangeId <= 622:
                this.setState({icon: this.weatherIcon.Snow});
                break;
            case rangeId >= 701 && rangeId <= 781:
                this.setState({icon: this.weatherIcon.Atmosphere});
                break;
            case rangeId === 800:
                this.setState({icon: this.weatherIcon.Clear});
                break;
            case rangeId >= 801 && rangeId <= 804:
                this.setState({icon: this.weatherIcon.Clouds});
                break;
            default:
                this.setState({icon: this.weatherIcon.Clouds}); 
        }
    }

    calculateCelsius = (temp) => {
        let cel = Math.floor(temp - 273.15);
        return cel;
    }

    getWeather = (e) => {
        e.preventDefault();
        const city = e.target.elements.city.value;

        if(city){
            fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${WEATHER_API_KEY}`)
            .then(data => data.json())
            .then(data => {
                console.log(data);
                this.setState({
                    city: `${data.name}`,
                    max_temp: this.calculateCelsius(data.main.temp_max),
                    min_temp: this.calculateCelsius(data.main.temp_min),
                    fahrenheit: this.calculateCelsius(data.main.temp),
                    description: data.weather[0].description,
                    error: false
                });
                this.getWeatherIcon(this.weatherIcon, data.weather[0].id);
            });
        }
        else{
            this.setState({
                error: true
            });
        }
    } 
    render(){
        return (
            <div className="container" style={{ margin: 20 }}>
                <SearchCity loadWeather={this.getWeather} error={this.state.error} />
                <SearchUniversity 
                    city={this.state.city} 
                    fahrenheit={this.state.fahrenheit}
                    max_temp={this.state.max_temp}
                    min_temp={this.state.min_temp}
                    description={this.state.description}  
                    weatherIcon={this.state.icon}
                />
            </div>
        );
    }
}

export default GetWeatherComponent;