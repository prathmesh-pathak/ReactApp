import React, { Component } from 'react';
import DisplayNews from './DisplayNews';

const GOOGLE_NEWS_API_KEY = process.env.REACT_APP_GOOGLE_NEWS_API_KEY;

class GoogleNews extends Component{
    constructor (props) {
        super(props);
        this.state = {
            articles: [],
            count: 0
        }
    }
    componentDidMount(){
        fetch(`https://newsapi.org/v2/top-headlines?sources=google-news&apiKey=${GOOGLE_NEWS_API_KEY}`)
        .then((response) => {
            return response.json();
        }).then((data) => {
            console.log(data);
            this.setState({
               articles: data.articles
            });
        });

        this.myInterval = setInterval(() => {
            this.setState({
                count: this.state.count + 1
            });
        }, 1000);
    }
    render() {
        if(this.state.count > 5){
            window.location.reload();
        }
        return (
            <div className="container mainContent">
            <h3 className="center" style={{ margin: 20 }}>Tops 10 news from around the world.</h3>
                {this.state.articles.map((items, index) => {
                    return (
                        <DisplayNews 
                            key={index} 
                            title={items.title} 
                            author={items.author}
                            description={items.description}
                            image={items.urlToImage}
                            readMore={items.url}
                        /> 
                    );
                })}
            </div>
        )
    }
}

export default GoogleNews;