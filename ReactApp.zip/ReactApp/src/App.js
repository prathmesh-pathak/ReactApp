import React, { Component } from 'react';
import Navigation from './component/Navigation';
import {BrowserRouter, Route} from 'react-router-dom'; 
import SearchMovieComponent from './component/SearchMovieComponent';
import GoogleNews from './component/GoogleNews';
import GetWeatherComponent from './component/GetWeatherComponent';
import Header from './component/Header';
import Info from './component/Info';

class App extends Component {
  render(){
    return (
      <BrowserRouter>
        <div className="Body">
          <Header />
          <Navigation />
          <Route path='/Info' component={Info} />
          <Route path='/SearchMovieComponent' component={SearchMovieComponent} />
          <Route path='/GoogleNews' component={GoogleNews} />
          <Route path='/GetWeatherComponent' component={GetWeatherComponent} />
        </div>
      </BrowserRouter>
    );
  }
}

export default App;